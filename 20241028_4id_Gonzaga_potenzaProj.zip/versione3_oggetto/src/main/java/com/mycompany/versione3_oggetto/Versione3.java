package com.mycompany.versione3_oggetto;

public class Versione3 {

    public static void main(String[] args) {
        
        Input_calcolo Potenza = new Input_calcolo ();
        
        Potenza.FunzioneInputCalcolo();
    }
}
