package com.mycompany.versione3_oggetto;
import java.util.Scanner;

public class Input_calcolo {

    public int base = 0;
    public int esponente = 0;
    public int risultato = 1;
    
    public void FunzioneInputCalcolo () {
       
        //Chiedo all'utente il valore della base
        Scanner InputBase = new Scanner(System.in);
        System.out.println("Inserisci il valore della base: ");
        
        //Assegno alla variabile "base" il valore dato dall'utente
        base = InputBase.nextInt();
        
        //Chiedo all'utente il valore della potenza
        Scanner InputEsponente = new Scanner(System.in);
        System.out.println("Inserisci il valore della esponente: ");
        
        //Assegno alla variabile "potenza" il valore dato dall'utente
        esponente = InputEsponente.nextInt();
        
        //Creo un for dove eseguiamo il calcolo della potenza
        for (int i = 0; i < esponente; i++){
            
            risultato = risultato * base;
            
        }
        
        //Stampo il valore della variabile "risultato"
        System.out.println("Il risultato della potenza e': " + risultato);
        
    }
       
}
